$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not $env:ARTEMIS_KEYSTORE_PASSWORD) { throw 'Defina ARTEMIS_KEYSTORE_PASSWORD con una contraseña de laboratorio de al menos 12 caracteres.' }
if ($env:ARTEMIS_KEYSTORE_PASSWORD.Length -lt 12) { throw 'Use al menos 12 caracteres.' }
if (Test-Path -LiteralPath 'certs/artemis-local.p12') { throw 'Ya existe el almacén. Consérvelo o muévalo antes de generar otro.' }
& keytool -genkeypair -alias artemis-local -keyalg RSA -keysize 3072 -sigalg SHA256withRSA -validity 365 -dname 'CN=localhost, OU=CS305, O=Artemis Financial' -ext 'SAN=dns:localhost,ip:127.0.0.1' -ext 'BC=ca:false' -ext 'KU=digitalSignature,keyEncipherment' -ext 'EKU=serverAuth' -storetype PKCS12 -keystore certs/artemis-local.p12 -storepass:env ARTEMIS_KEYSTORE_PASSWORD
if ($LASTEXITCODE -ne 0) { throw 'Error de Keytool al generar el certificado.' }
& keytool -exportcert -rfc -alias artemis-local -keystore certs/artemis-local.p12 -storepass:env ARTEMIS_KEYSTORE_PASSWORD -file certs/artemis-local.cer
if ($LASTEXITCODE -ne 0) { throw 'Error de Keytool al exportar el certificado.' }
& keytool '-J-Duser.language=en' '-J-Duser.country=US' -printcert -v -file certs/artemis-local.cer
if ($LASTEXITCODE -ne 0) { throw 'Error de Keytool al inspeccionar el certificado.' }
