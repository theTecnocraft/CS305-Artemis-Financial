"""Integration tests with certificate and hostname validation enabled; Python 3.10+."""
from pathlib import Path
import ssl, socket, http.client, hashlib, json, concurrent.futures

root=Path(__file__).resolve().parents[1]
cert=root/'certs/artemis-local.cer'
context=ssl.create_default_context(cafile=str(cert))
data='Francis Joseph Anton Giler | Artemis Financial | CS305-II | 2026-10-19 | 7bd672c2-091e-4e55-9972-38e363c5b321'
results=[]
def record(name, passed, detail):
 results.append({'prueba':name,'resultado':'PASS' if passed else 'FAIL','detalle':detail})
 if not passed: raise AssertionError(name+': '+str(detail))
def request(method='GET',path='/hash',ctx=context):
 conn=http.client.HTTPSConnection('localhost',8443,context=ctx,timeout=10)
 conn.request(method,path);res=conn.getresponse()
 out=(res.status,dict(res.getheaders()),res.read().decode('utf-8'))
 conn.close();return out
status,headers,body=request()
record('HTTPS con certificado y nombre verificados',status==200,{'status':status,'hostname_validation':context.check_hostname,'certificate_validation':context.verify_mode.name})
expected=hashlib.sha256(data.encode('utf-8')).hexdigest()
record('Checksum independiente con hashlib',expected in body,expected)
record('Identidad y cadena única',data in body and 'Francis Joseph Anton Giler' in body,data)
record('Tipo de contenido seguro',headers.get('Content-Type','').lower().startswith('text/plain'),headers.get('Content-Type'))
record('Cabeceras de seguridad',headers.get('X-Content-Type-Options')=='nosniff' and headers.get('Cache-Control')=='no-store',headers)
record('POST no permitido',request('POST')[0]==405,'HTTP 405')
status,_,errorbody=request('GET','/no-existe')
record('Ruta desconocida sin trazas',status==404 and 'java.' not in errorbody and 'stackTrace' not in errorbody,{'status':status,'body':errorbody})
record('Parámetros no alteran datos de demostración',request('GET','/hash?data=%3Cscript%3E')[2]==body,'La ruta utiliza exclusivamente datos constantes')
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 replies=list(pool.map(lambda _:request()[2],range(30)))
record('30 solicitudes concurrentes',all(r==body for r in replies),'30/30 respuestas idénticas')
for version in [ssl.TLSVersion.TLSv1_2,ssl.TLSVersion.TLSv1_3]:
 ctx=ssl.create_default_context(cafile=str(cert));ctx.minimum_version=version;ctx.maximum_version=version
 with socket.create_connection(('localhost',8443),timeout=10) as raw:
  with ctx.wrap_socket(raw,server_hostname='localhost') as tls:
   record(version.name,True,{'protocol':tls.version(),'cipher':tls.cipher()})
try:
 with socket.create_connection(('localhost',8443),timeout=10) as raw:
  with context.wrap_socket(raw,server_hostname='incorrecto.example'): pass
 record('Rechazo de nombre incorrecto',False,'Se aceptó un nombre incorrecto')
except ssl.SSLCertVerificationError:
 record('Rechazo de nombre incorrecto',True,'SSLCertVerificationError')
try:
 with socket.create_connection(('localhost',8443),timeout=10) as raw:
  with ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT).wrap_socket(raw,server_hostname='localhost'): pass
 record('Rechazo sin confianza explícita',False,'Se aceptó sin CA explícita')
except ssl.SSLCertVerificationError:
 record('Rechazo sin confianza explícita',True,'El certificado autofirmado exige confianza explícita')
plain=http.client.HTTPConnection('localhost',8443,timeout=10)
try:
 plain.request('GET','/hash');res=plain.getresponse();plainbody=res.read().decode('utf-8','replace')
 record('HTTP no entrega datos',res.status!=200 and expected not in plainbody,f'HTTP {res.status}')
except (ConnectionError,http.client.HTTPException):
 record('HTTP no entrega datos',True,'Conexión HTTP rechazada')
finally: plain.close()
report={'pruebas':results,'total':len(results),'passed':sum(r['resultado']=='PASS' for r in results),'checksum':expected}
(root/'evidencias/https-tests.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
(root/'evidencias/hash-response.txt').write_text(body,encoding='utf-8')
for r in results: print(f"{r['resultado']}: {r['prueba']}: {r['detalle']}")
print(f"TOTAL: {report['passed']}/{report['total']} PASS")
