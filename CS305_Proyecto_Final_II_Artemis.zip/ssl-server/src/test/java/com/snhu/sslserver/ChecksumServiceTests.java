package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.stream.IntStream;

class ChecksumServiceTests {
    private final ChecksumService service = new ChecksumService();
    @Test void knownVectorAbc() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", service.sha256("abc"));
    }
    @Test void emptyInput() {
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", service.sha256(""));
    }
    @Test void rejectsNull() { assertThrows(NullPointerException.class, () -> service.sha256(null)); }
    @Test void detectsAlteration() { assertNotEquals(service.sha256(HashController.DATA), service.sha256(HashController.DATA + ".")); }
    @Test void fixedWidthLowercaseHex() { assertTrue(service.sha256(HashController.DATA).matches("[0-9a-f]{64}")); }
    @Test void concurrentRequestsAreIndependent() {
        var expected = IntStream.range(0,200).mapToObj(i -> service.sha256("data-" + i)).toList();
        var actual = IntStream.range(0,200).parallel().mapToObj(i -> service.sha256("data-" + i)).toList();
        assertEquals(expected,actual);
    }
    @Test void controllerShowsIdentityAndComputedDigest() {
        String response = new HashController(service).hash();
        assertTrue(response.contains(HashController.DATA));
        assertTrue(response.contains(service.sha256(HashController.DATA)));
    }
}
