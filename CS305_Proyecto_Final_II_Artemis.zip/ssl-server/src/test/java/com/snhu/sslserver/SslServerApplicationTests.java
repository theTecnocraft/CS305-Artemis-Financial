package com.snhu.sslserver;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE, properties = "server.ssl.enabled=false")
class SslServerApplicationTests {
    @Test void contextLoads() { }
}
