package com.snhu.sslserver;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public final class HashController {
    public static final String DATA = "Francis Joseph Anton Giler | Artemis Financial | CS305-II | 2026-10-19 | 7bd672c2-091e-4e55-9972-38e363c5b321";
    private final ChecksumService checksums;

    public HashController(ChecksumService checksums) { this.checksums = checksums; }

    @GetMapping(value = "/hash", produces = MediaType.TEXT_PLAIN_VALUE)
    public String hash() {
        return "Artemis Financial - Verificación de integridad\n"
            + "Desarrollador: Francis Joseph Anton Giler\n"
            + "Algoritmo: SHA-256 (256 bits / 64 caracteres hexadecimales)\n"
            + "Codificación: UTF-8\n\nDatos exactos:\n" + DATA
            + "\n\nSuma de comprobación:\n" + checksums.sha256(DATA) + "\n";
    }
}
