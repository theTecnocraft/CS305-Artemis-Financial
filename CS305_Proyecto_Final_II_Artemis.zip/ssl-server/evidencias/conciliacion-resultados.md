# Conciliación de resultados

## Análisis final

| Magnitud | Recuento | Fuente |
| --- | ---: | --- |
| Objetos principales | 41 | dependency-check-report.json: dependencies |
| Registros relacionados | 27 | Suma de relatedDependencies |
| Entradas examinadas | 68 | HTML: Dependencies Scanned, incluye los registros relacionados |
| Dependencias únicas | 41 | Resumen HTML |
| Vulnerabilidades | 0 | Sin elementos vulnerabilities en las dependencias del JSON |
| Supresiones | 0 | Resumen HTML |

Los 68 registros no son 68 bibliotecas únicas ni un recuento de alertas. La última comprobación NVD registrada es 2026-10-12T00:31:51+02; la última modificación es 2026-10-11T22:16:50Z. La ejecución no cubre avisos posteriores.

## Análisis anterior

dependency-check-before.json contiene los siguientes once identificadores distintos, todos asociados a tomcat-embed-core-11.0.24.jar. Son coincidencias del analizador, no explotaciones demostradas. El análisis final corresponde a Tomcat 11.0.27.

- CVE-2026-65637
- CVE-2026-65905
- CVE-2026-65182
- CVE-2026-68525
- CVE-2026-65183
- CVE-2026-66422
- CVE-2026-68569
- CVE-2026-65927
- CVE-2026-68763
- CVE-2026-73180
- CVE-2026-66299

## Pruebas

- Surefire: 8 pruebas; 0 fallos, 0 errores y 0 omitidas. Fuentes: surefire-reports/TEST-*.xml.
- HTTPS: 14 comprobaciones, 14 PASS. Fuente: https-tests.json.
- Los 200 cálculos concurrentes y las 30 solicitudes son casos internos de las pruebas; no se añaden al total de pruebas.

## Capturas

03-hash.png conserva el contenido de la página de la ejecución inicial. 09-https-barra-direccion.png incorpora la barra y conserva «No seguro». Esa captura no prueba confianza del navegador. La prueba del cliente carga explícitamente el CER y valida el certificado y el nombre del servidor.
