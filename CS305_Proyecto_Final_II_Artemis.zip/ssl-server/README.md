# Artemis Financial — CS305 Proyecto final II

Autor: Francis Joseph Anton Giler. Evaluación: 19 de octubre de 2026.

Servicio local que expone `https://localhost:8443/hash`, muestra una cadena de datos única y su SHA-256. La aplicación utiliza TLS; el hash no es cifrado reversible ni una firma digital.

## Requisitos

- JDK 21 o posterior compatible con Spring Boot 4.1.1; probado con JDK 25.0.4.
- Maven 3.9.11 o el wrapper incluido. La primera compilación necesita Internet.
- PowerShell 7 para los comandos de generación mostrados abajo; Java Keytool debe estar en PATH.
- Python 3.10+ solo para las pruebas de integración, sin paquetes adicionales.
- Eclipse con integración Maven si se desea utilizar el IDE.

## Importar en Eclipse

1. Extraer el ZIP en una carpeta local.
2. File > Import > Maven > Existing Maven Projects; seleccionar la carpeta `ssl-server` y su `pom.xml`.
3. Seleccionar el JDK adecuado en Installed JREs y actualizar el proyecto Maven.
4. Las configuraciones `.launch` de `eclipse/` ejecutan Java Keytool como herramienta externa. Suponen que el proyecto importado se llama `ssl-server` y que `JAVA_HOME` está definido al iniciar Eclipse. Si Eclipse asigna otro nombre, ajustar la variable `workspace_loc` en estas configuraciones.

## Certificado y ejecución

El CER incluido es el certificado público de la ejecución documentada. **No se incluye la clave privada ni su contraseña.** Cada persona debe generar un almacén local nuevo; la nueva huella será diferente de la del informe.

Desde PowerShell, en la raíz del proyecto:

```powershell
$env:ARTEMIS_KEYSTORE_PASSWORD = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
.\scripts\generar-certificado.ps1
.\mvnw.cmd -B -ntp package
java -jar target/ssl-server-1.0.0.jar
```

Mantener esa sesión abierta: el servidor recibe la contraseña por el entorno. Guardar la contraseña solo en un mecanismo local seguro si se necesita reutilizar el mismo almacén en otra sesión. El script se detiene si ya existe `certs/artemis-local.p12`, para no sobrescribir una clave existente.

En Eclipse, ejecutar primero `01 Generar certificado.launch`, después `02 Exportar CER.launch`; definir `ARTEMIS_KEYSTORE_PASSWORD` en el entorno antes de iniciar Eclipse o en la configuración local de ejecución. No guardar contraseñas en una configuración compartida. Alternativamente, ejecutar el script de PowerShell y usar Run As > Java Application con `SslServerApplication`, configurando el directorio de trabajo en la raíz y la misma variable de entorno.

El servidor escucha exclusivamente en `127.0.0.1:8443`. Un navegador mostrará una advertencia si no confía en el certificado autofirmado. Para un laboratorio puede confiarse explícitamente en el certificado público después de verificar su huella; no es necesario modificar el almacén del sistema para ejecutar las pruebas siguientes.

## Verificar

En otra sesión, desde la raíz:

```powershell
python .\scripts\verificar_https.py
```

El cliente carga `certs/artemis-local.cer`, verifica el certificado y `localhost`, compara SHA-256 con `hashlib`, prueba 30 solicitudes concurrentes, TLS 1.2/1.3, errores y solicitudes HTTP no cifradas. Esperado: `TOTAL: 14/14 PASS`. El contexto de la prueba negativa no carga ninguna raíz de confianza. No se desactiva la validación TLS.

```powershell
.\mvnw.cmd -B -ntp test
.\mvnw.cmd -B -ntp verify
```

`test` ejecuta ocho pruebas JUnit. `verify` añade Dependency-Check 13.0.0. `package` por sí solo no ejecuta el análisis de vulnerabilidades. Cualquier vulnerabilidad con CVSS >= 0 detiene `verify`.

## Resultado y límites del análisis adjunto

- Spring Boot 4.1.1 y Tomcat 11.0.27.
- Ocho pruebas JUnit y catorce pruebas HTTPS satisfactorias.
- Dependency-Check: 41 objetos principales en el JSON + 27 registros relacionados = 68 entradas examinadas en el HTML (41 únicas); cero vulnerabilidades y cero supresiones. Véase `evidencias/conciliacion-resultados.md`.
- El primer análisis detectó once CVE en Tomcat 11.0.24; se corrigió actualizando a 11.0.27. El informe `before` conserva esa evidencia y los errores de actualización iniciales.
- La actualización NVD en línea falló con un error de API. La ejecución final utilizó una copia local con última comprobación del **12/10/2026 a las 00:31:51 +02** y última modificación **11/10/2026 22:16:50 UTC**. No cubre avisos posteriores.
- El analizador .NET se desactiva por no haber ensamblados .NET. Sonatype OSS Index no se ejecutó por falta de credenciales. Se incluyeron las dependencias de pruebas.

La ejecución documentada usó:

```text
mvn -B -ntp verify -DdataDirectory=<copia-local-datos-NVD> -DautoUpdate=false -DassemblyAnalyzerEnabled=false
```

La base de datos NVD no se distribuye en el ZIP por su tamaño. Para una comprobación actual, usar `verify` con actualización satisfactoria. Si se necesita una clave NVD, configurarla de forma local y protegida siguiendo la documentación del complemento; no incluirla en el código ni en el informe. El POM mantiene las actualizaciones habilitadas por defecto y falla ante errores.

## Archivos

- `src/`: código y pruebas.
- `certs/artemis-local.cer`: certificado público de la evidencia.
- `eclipse/`: configuraciones portables para generar/exportar el certificado con Keytool.
- `scripts/`: generación del certificado y prueba HTTPS.
- `evidencias/`: informes originales, logs, capturas completas y detalles recortados identificados.
- `pom-original.xml`: POM del esqueleto suministrado, únicamente como referencia; compilar con `pom.xml`.
- `.mvn/`, `mvnw`, `mvnw.cmd`: wrapper Maven.

Las capturas de registros indican cuando muestran un extracto. La captura inicial de la página HTTPS incluye su contenido. La captura adicional 09-https-barra-direccion.png muestra también la dirección y la advertencia «No seguro»: no demuestra confianza del navegador en el certificado autofirmado. La captura de Eclipse conserva el resultado de la generación; sus detalles se verifican también en el CER y el registro Keytool. Se retiró la confianza temporal añadida durante las capturas.

## Alcance de seguridad

Demostración local de checksum y transporte seguro. No implementa cuentas, operaciones financieras, autenticación/autorización ni carga de archivos. Antes de producción se requieren certificado del dominio real, gestión de secretos, revisión del despliegue, actualización de vulnerabilidades y controles específicos de las funciones nuevas.
